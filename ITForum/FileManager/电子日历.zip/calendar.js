var today = new Date();
// 获取当前年份
var year = today.getFullYear();
// 获取当前月份
var month = today.getMonth() + 1;
// 获取当前日期
var day = today.getDate();

// 当前月份的总天数
var allDay = 0;

// 用于推算当前月份一共多少天
function count(){
    var arr = new Array(13);
    arr = [0,31,28,31,30,31,30,31,31,30,31,30,31];
    if(((year % 4)==0 && (year % 100)!=0) || (year % 400)==0){
        arr[2] = 29;
    } else{
        arr[2] = 28;
    }
    allDay = arr[month];  
}

function showDate(){

}